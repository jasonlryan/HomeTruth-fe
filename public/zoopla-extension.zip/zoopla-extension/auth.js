const tokenMatch = window.location.hash.match(/access_token=([^&]+)/);
const token = tokenMatch ? tokenMatch[1] : null;

if (token) {
  chrome.storage.local.set({ authToken: token }, () => {
    console.log("✅ Token stored:", token);
    window.close();
  });
} else {
  console.error("❌ No token found in URL.");
}
