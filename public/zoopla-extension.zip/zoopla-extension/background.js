chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "PROPERTY_CLICKED") {
    console.log("📩 Background received property:", message.url);
    chrome.storage.local.set({ lastPropertyUrl: message.url });
  }
});
